export interface User {
  id: string;
  username: string;
  balance: number;
  createdAt: string;
}